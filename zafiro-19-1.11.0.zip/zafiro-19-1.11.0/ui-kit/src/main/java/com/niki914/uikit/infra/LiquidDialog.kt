package com.niki914.uikit.infra

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.highlight.Highlight
import com.niki914.uikit.base.LocalAppDarkTheme
import com.niki914.uikit.infra.shape.G2FieldShape
import java.util.concurrent.atomic.AtomicLong

/** 选项列表过高时只滚正文，标题和按钮留在外面。 */
private val DialogBodyMaxHeight = 288.dp

internal class LiquidDialogHostEntry(
    val id: Long,
    initialVisible: Boolean,
    content: @Composable () -> Unit,
) {
    var content by mutableStateOf(content)
        internal set
    var visible by mutableStateOf(initialVisible)
        internal set
}

internal class LiquidDialogHostState {
    private val mutableEntries = mutableStateListOf<LiquidDialogHostEntry>()

    val entries: List<LiquidDialogHostEntry>
        get() = mutableEntries

    val hasActiveDialog: Boolean
        get() = mutableEntries.any { it.visible }

    internal fun upsert(id: Long, visible: Boolean, content: @Composable () -> Unit) {
        val entry = mutableEntries.firstOrNull { it.id == id }
        if (entry != null) {
            entry.content = content
            entry.visible = visible
        } else {
            mutableEntries += LiquidDialogHostEntry(
                id = id,
                initialVisible = visible,
                content = content
            )
        }
    }

    internal fun remove(id: Long) {
        mutableEntries.removeAll { it.id == id }
    }
}

val LocalHasActiveDialog: ProvidableCompositionLocal<Boolean> =
    staticCompositionLocalOf { false }

internal val LocalLiquidDialogHostState: ProvidableCompositionLocal<LiquidDialogHostState?> =
    compositionLocalOf { null }

internal val liquidDialogHostEntryId = AtomicLong(0L)

internal fun nextLiquidDialogHostEntryId(): Long = liquidDialogHostEntryId.incrementAndGet()

@Composable
fun LiquidDialog(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    dismissOnBackgroundTap: Boolean = true,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    actions: (@Composable RowScope.() -> Unit)? = null,
    content: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val hostState = LocalLiquidDialogHostState.current
        ?: error("LiquidDialog must be used inside LiquidScreen")
    val dialogId = remember { nextLiquidDialogHostEntryId() }

    SideEffect {
        hostState.upsert(dialogId, visible) {
            LiquidDialogSurface(
                visible = visible,
                onDismissRequest = onDismissRequest,
                modifier = modifier,
                dismissOnBackgroundTap = dismissOnBackgroundTap,
                title = title,
                text = text,
                actions = actions,
                content = content,
            )
        }
    }

    DisposableEffect(hostState, dialogId) {
        onDispose {
            hostState.remove(dialogId)
        }
    }
}

@Composable
private fun LiquidDialogSurface(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    dismissOnBackgroundTap: Boolean = true,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    actions: (@Composable RowScope.() -> Unit)? = null,
    content: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val fallbackBackdrop = rememberLayerBackdrop()
    val resolvedBackdrop = LocalScreenBackdrop.current ?: fallbackBackdrop
    val isDarkTheme = LocalAppDarkTheme.current
    val colorScheme = MaterialTheme.colorScheme
    val scrimColor = colorScheme.scrim.copy(alpha = 0.42f)
    val panelSurfaceColor = LiquidGlassPresets.Dialog.surfaceColor(isDarkTheme, colorScheme)
    val panelTintColor = colorScheme.primaryContainer.copy(alpha = 0.18f)
    val interactionSource = remember { MutableInteractionSource() }
    val panelShape = G2FieldShape(48.dp)

    // 治本：调用方条件组合（首帧 visible 即 true）时，AnimatedVisibility 无过渡可播、
    // 直接闪现。这里先按 false 渲染一帧再翻转，强制播放入场过渡；对常驻
    // 组合（先 false 后翻 true）的调用姿势无影响。
    var dialogMounted by remember { mutableStateOf(false) }
    val effectiveVisible = dialogMounted && visible
    LaunchedEffect(Unit) {
        withFrameNanos { }
        dialogMounted = true
    }

    // LiquidDialog 是 portal overlay 而不是 Dialog，不会自动接管焦点：显示时必须主动
    // 释放页面上残留的输入焦点，否则键盘会继续顶在弹窗上、焦点也仍留在背后的输入框里。
    // （弹窗自带输入框的调用方在更晚的时机 requestFocus，仍然能拿到焦点。）
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    LaunchedEffect(effectiveVisible) {
        if (effectiveVisible) {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
        }
    }

    // 弹窗可见时消费系统返回键（issue：语言/协议弹窗按返回直接弹页）。
    // LiquidDialog 是 portal overlay 而非 Dialog，返回不会自动落在弹窗上；
    // 这里后于页面级 BackHandler 注册（弹窗内容组合在后），可见时优先接管，
    // 隐藏后随 AnimatedVisibility 自动注销。
    BackHandler(enabled = effectiveVisible) {
        onDismissRequest()
    }

    val scaleAnimationSpec = if (effectiveVisible) {
        tween<Float>(durationMillis = 240, easing = FastOutSlowInEasing)
    } else {
        tween<Float>(durationMillis = 180, easing = FastOutSlowInEasing)
    }
    val targetScale = if (effectiveVisible) 1f else 1.04f
    val panelScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = scaleAnimationSpec,
        label = "liquidDialogPanelScale",
    )

    AnimatedVisibility(
        visible = effectiveVisible,
        enter = fadeIn(animationSpec = tween(120, easing = LinearEasing)),
        exit = fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing)),
    ) {
        BoxWithConstraints(
            modifier = modifier
                .fillMaxSize()
                .imePadding(),
            contentAlignment = Alignment.Center,
        ) {
            val horizontalMargin = 24.dp
            val verticalMargin = 24.dp
            val maxPanelWidth = (maxWidth - horizontalMargin * 2)
                .coerceAtLeast(0.dp)
                .coerceAtMost(360.dp)
            val minPanelWidth = if (maxPanelWidth < 200.dp) {
                maxPanelWidth
            } else {
                200.dp
            }
            val maxPanelHeight = (maxHeight - verticalMargin * 2).coerceAtLeast(0.dp)
            val scrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(scrimColor)
                    .clickable(
                        enabled = true,
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = {
                            if (dismissOnBackgroundTap) {
                                onDismissRequest()
                            }
                        },
                    ),
            )

            Column(
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = panelScale
                        scaleY = panelScale
                    }
                    .padding(horizontal = horizontalMargin, vertical = verticalMargin)
                    .widthIn(min = minPanelWidth, max = maxPanelWidth)
                    .heightIn(max = maxPanelHeight)
                    .drawBackdrop(
                        backdrop = resolvedBackdrop,
                        shape = { panelShape },
                        highlight = { LiquidGlassPresets.Dialog.highlight(isDarkTheme) },
                        shadow = { LiquidGlassPresets.Dialog.shadow(isDarkTheme) },
                        effects = {
                            LiquidGlassPresets.Dialog.applyEffects(this, isDarkTheme)
                        },
                        onDrawSurface = {
                            drawRect(panelTintColor, blendMode = BlendMode.Hue)
                            drawRect(panelSurfaceColor)
                        },
                    )
                    .clip(panelShape)
                    .clickable(
                        enabled = true,
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = {},
                    )
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                title?.invoke()
                if (text != null || content != null) {
                    Column(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .heightIn(max = DialogBodyMaxHeight)
                            .verticalScroll(scrollState)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        text?.invoke()
                        content?.invoke(this)
                    }
                }
                if (actions != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        content = actions,
                    )
                }
            }
        }
    }
}
